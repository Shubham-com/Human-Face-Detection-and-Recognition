```python
pip install numpy
```

    Requirement already satisfied: numpy in c:\programdata\anaconda3\lib\site-packages (1.16.5)
    Note: you may need to restart the kernel to use updated packages.
    


```python
pip install opencv-python
```

    Requirement already satisfied: opencv-python in c:\programdata\anaconda3\lib\site-packages (4.2.0.34)
    Requirement already satisfied: numpy>=1.14.5 in c:\programdata\anaconda3\lib\site-packages (from opencv-python) (1.16.5)
    Note: you may need to restart the kernel to use updated packages.
    


```python
import cv2
import numpy as np
import matplotlib.pyplot as plt
```


```python
img=plt.imread(r"C:\Users\HP\Desktop\Face recognisation\images.jpg")
```


```python
plt.imshow(img)
```




    <matplotlib.image.AxesImage at 0x1bbd07cb948>




![png](output_4_1.png)



```python
detector=cv2.CascadeClassifier(r"C:\Users\HP\Desktop\Face recognisation\haarcascade_frontalface_alt.xml")
```


```python
faces=detector.detectMultiScale(img)
```


```python
faces
```




    array([[ 79,  37,  35,  35],
           [141,  41,  32,  32],
           [188,  41,  34,  34],
           [ 37,  28,  42,  42],
           [231,  16,  39,  39]], dtype=int32)




```python
faces.shape
```




    (5, 4)




```python
faces[0]
```




    array([79, 37, 35, 35], dtype=int32)




```python
x,y,w,h=faces[0]
```


```python
x
```




    79




```python
y
```




    37




```python
w
```




    35




```python
h
```




    35




```python
img=cv2.rectangle(img,(x,y),(x+w,y+h),(255,255,255),2)
```


```python
plt.imshow(img)
```




    <matplotlib.image.AxesImage at 0x1bbd1163f88>




![png](output_16_1.png)



```python
#PLOT RECTANGLE FOR ALL FACES

for face in faces:
    x,y,w,h=face
    img=cv2.rectangle(img,(x,y),(x+w,y+h),(255,255,255),2)
    plt.imshow(img)

```


![png](output_17_0.png)



```python

```


```python

```
